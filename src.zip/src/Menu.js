import React from 'react'


 const Menu = () => {
    return (
        <div>
            <h1>Menu</h1>
        </div>
    )
}
export default Menu; 